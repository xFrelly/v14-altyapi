const fs = require('fs');
const { REST } = require('@discordjs/rest'); //Eğer hata verirse npm i komutuyla yükle.
const { Routes } = require('discord-api-types/v10');//Eğer hata verirse npm i komutuyla yükle.
module.exports = (client) => {
    client.handleCommands = async () => {
        const commandFolders = fs.readdirSync(`./src/commands`);
        for (const folder of commandFolders) {
            const commandFiles = fs
                .readdirSync(`./src/commands/${folder}`)
                .filter((file) => file.endsWith('.js'));
            const { commands, commandArray } = client;
            for (const file of commandFiles) {
                const command = require(`../../commands/${folder}/${file}`);
                commands.set(command.data.name, command);
                commandArray.push(command.data.toJSON());
                console.log(`${command.data.name} komutu girildi.`);
            }
        }
        const clientId = ''; //Botun idsini buraya yapıştır.
        const guildId = ''; //Sunucu idsini buraya yapıştır.
        const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
        try {
            console.log('Slash (/) komutları şimdi entegre ediliyor.');

            await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
                body: client.commandArray,
            });

            console.log('Slash(/) komutları başarıyla entegre edildi.');

        } catch (error) {
            console.log(error)

        }
    }
}