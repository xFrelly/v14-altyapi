//Örnek bir komut modülü.
module.exports = {
    name: 'Komut ismi',
    aliases: ['alias1', 'alias2'],
    description: 'Komut açıklaması',
    async execute(message, args, client) {
        // Komutun mantığı buraya.
        await message.reply('Komut çalıştırıldı.');
    },
};