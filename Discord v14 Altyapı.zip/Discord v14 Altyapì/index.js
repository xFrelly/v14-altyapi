const { Client, GatewayIntentBits, ActivityType, Collection , EmbedBuilder } = require('discord.js');
require('dotenv').config();
const fs = require('fs');
//fs ve dotenv package.json a eklidir.
const client = new Client({
  intents: [ GatewayIntentBits.Guilds , GatewayIntentBits.GuildMessages]


});
client.commands = new Collection();
client.commandArray = [];
const functionFolder = fs.readdirSync(`./src/functions/`);
for (const folder of functionFolder) {
  const functionFiles = fs
    .readdirSync(`./src/functions/${folder}`)
    .filter(file => file.endsWith('.js'));
  for (const files of functionFiles) {
    require(`./functions/${folder}/${files}`)(client);
  }

}
//Burası komutların farklı dosya ortamlarında çalışabilmesi için gerekli olan kodların dizimi.
client.handleEvents();
client.handleCommands();
client.login(process.env.token);